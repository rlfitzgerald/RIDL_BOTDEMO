import folium
import pdb
from folium.plugins import MarkerCluster # for marker clusters
import pandas as pd
def _gen_map(lat,lon,markers,geojson,filename="default.html"):
	map_osm = folium.Map(location=[lat,lon],zoom_start=14)
	if geojson != None:
		G=folium.GeoJson(open(geojson))
		G.add_to(map_osm) 
	if markers != None:
		pass		
	map_osm.save(filename)
	return map_osm,filename

def _gen_map_locs(locs):
	map_osm = folium.Map(location=[-33.23,-118.234],zoom_start=14)
	marker_cluster = MarkerCluster(locations=locs,popups=locs)
	map_osm.add_children(marker_cluster)
	map_osm.save("testtest.html")
	
def _get_locs(filename):
	locs = []
	fp =open(filename)
	headerline = fp.readline()
	for j in fp.readlines():
		lon = j.split(",")[1]	
		lat = j.split(",")[2]	
		locs.append([float(lat),float(lon)])
	return locs

def mmap(lat,lon,geojson=None):
	map_file,filename=_gen_map(lat,lon,markers=None,geojson=geojson)
	f = " ".join(open(filename).readlines())
	print f	
	return f	
#	div,script=get_div_script(map_file)
#	div_string = str(div)	
#	script_string = str(script)	
#	return  div_string+script_string
def test():
	lat=33.734
	lon=-118.2373
	maps = mmap(lat,lon,geojson="/tmp/x.geojson")
	print maps

locs = _get_locs("shiplocs.csv")
_gen_map_locs(locs)
